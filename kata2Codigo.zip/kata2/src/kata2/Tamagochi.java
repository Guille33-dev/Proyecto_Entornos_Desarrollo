package kata2;

/**
 * Clase que implementa un Tamagochi con atributos de hambre,
 * energía y humor, y métodos para jugar, comer y dormir.
 */
public class Tamagochi {

    // Atributos
    private int hunger;
    private int energy;
    private int mood;

    // Constructor
    public Tamagochi() {
        this.hunger = 4;
        this.energy = 4;
        this.mood = 4;
    }

    /**
     * Método para jugar con el Tamagochi.
     * Aumenta el hambre y el humor en 1, disminuye la energía en 1.
     * Devuelve el estado actual del Tamagochi.
     */
    public String play() {
        hunger++;
        mood++;
        energy--;
        return getState();
    }

    /**
     * Método para alimentar al Tamagochi.
     * Disminuye el hambre en 2, disminuye la energía en 1.
     * Devuelve el estado actual del Tamagochi.
     */
    public String eat() {
        hunger -= 2;
        energy--;
        if (hunger < 0) hunger = 0; // Controla que el hambre no sea negativa.
        return getState();
    }

    /**
     * Método para que el Tamagochi duerma.
     * Aumenta la energía en 2.
     * Devuelve el estado actual del Tamagochi.
     */
    public String sleep() {
        energy += 2;
        return getState();
    }

    /**
     * Obtiene el estado actual del Tamagochi según los valores de sus atributos.
     * Devuelve una cadena representando el estado del Tamagochi.
     */
    private String getState() {
        if (energy == 0) {
            return "(-_-) zZZ"; // Dormido
        } else if (energy < 3) {
            return "(-_-)"; // Cansado
        } else if (mood > 8) {
            return ":-)"; // Contento
        } else if (mood < 2) {
            return "ఠ_ఠ"; // Enfadado
        } else {
            return ":-|"; // Normal
        }
    }

    // Método principal para probar el Tamagochi
    public static void main(String[] args) {
        Tamagochi myTamagochi = new Tamagochi();

        // Ejemplo de uso
        System.out.println(myTamagochi.play()); // Jugar
        System.out.println(myTamagochi.eat());  // Comer
        System.out.println(myTamagochi.sleep()); // Dormir
    }
}
