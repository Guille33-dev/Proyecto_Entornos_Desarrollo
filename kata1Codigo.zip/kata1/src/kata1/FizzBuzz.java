package kata1;

public class FizzBuzz {
    public static void main(String[] args) {
        // Recorre los números del 1 al 100
        for (int i = 1; i <= 100; i++) {
            if (i % 3 == 0 && i % 5 == 0) {
                // Múltiplo de 3 y 5
                System.out.println("FizzBuzz");
            } else if (i % 3 == 0) {
                // Múltiplo de 3
                System.out.println("Fizz");
            } else if (i % 5 == 0) {
                // Múltiplo de 5
                System.out.println("Buzz");
            } else {
                // No es múltiplo de ninguno
                System.out.println(i);
            }
        }
    }
}
